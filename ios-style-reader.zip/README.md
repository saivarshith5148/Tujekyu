# iOS Style Reader

A Freedium-inspired, distraction-free reader UI for **publicly accessible articles**.

## Run

Requires Node.js 18+.

```bash
npm install
npm start
```

Then open:

```text
http://localhost:3000
```

Paste a publicly accessible article URL.

## Features

- iOS-style glassmorphism UI
- Responsive mobile layout
- Dark mode
- Adjustable text size
- Adjustable line spacing
- Reading progress
- Reading-time estimate
- Article extraction with Mozilla Readability
- No client-side CORS dependency

## Important

This project is intentionally designed for content that is publicly accessible or that you are authorized to access. It does not bypass paywalls, authentication, robots restrictions, or other access controls.
