const express = require("express");
const { Readability } = require("@mozilla/readability");
const { JSDOM } = require("jsdom");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static(__dirname));

app.get("/api/article", async (req, res) => {
  const target = req.query.url;

  if (!target) {
    return res.status(400).json({ error: "Missing URL" });
  }

  let parsed;
  try {
    parsed = new URL(target);
    if (!["http:", "https:"].includes(parsed.protocol)) {
      throw new Error("Unsupported protocol");
    }
  } catch {
    return res.status(400).json({ error: "Invalid URL" });
  }

  try {
    const response = await fetch(parsed.href, {
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; CleanReader/1.0)"
      },
      redirect: "follow"
    });

    if (!response.ok) {
      return res.status(502).json({
        error: `Source returned HTTP ${response.status}`
      });
    }

    const html = await response.text();
    const dom = new JSDOM(html, { url: response.url });
    const article = new Readability(dom.window.document).parse();

    if (!article) {
      return res.status(422).json({
        error: "No readable public article content was found."
      });
    }

    res.json({
      title: article.title,
      description: article.excerpt || "",
      image: article.lead_image_url || "",
      siteName: parsed.hostname,
      content: article.content
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: "Could not retrieve the publicly accessible article."
    });
  }
});

app.listen(PORT, () => {
  console.log(`Reader running at http://localhost:${PORT}`);
});
