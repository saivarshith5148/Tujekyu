const form=document.getElementById("readerForm");
const input=document.getElementById("urlInput");
const home=document.getElementById("home");
const reader=document.getElementById("reader");
const controls=document.getElementById("readerControls");
const title=document.getElementById("articleTitle");
const description=document.getElementById("articleDescription");
const content=document.getElementById("articleContent");
const image=document.getElementById("articleImage");
const source=document.getElementById("articleSource");
const readingTime=document.getElementById("readingTime");
const progressBar=document.getElementById("progressBar");
const themeBtn=document.getElementById("themeBtn");
const settingsBtn=document.getElementById("settingsBtn");
const settings=document.getElementById("settings");
const closeSettings=document.getElementById("closeSettings");
const fontSlider=document.getElementById("fontSlider");
const spacingSlider=document.getElementById("spacingSlider");
const toast=document.getElementById("toast");
const backBtn=document.getElementById("backBtn");
const shareBtn=document.getElementById("shareBtn");
const decreaseFont=document.getElementById("decreaseFont");
const increaseFont=document.getElementById("increaseFont");

form.addEventListener("submit",async event=>{
  event.preventDefault();
  const url=input.value.trim();
  if(!url)return;
  try{new URL(url)}catch{showToast("Enter a valid URL");return}
  showToast("Loading article…");
  try{
    const response=await fetch(`/api/article?url=${encodeURIComponent(url)}`);
    const data=await response.json();
    if(!response.ok)throw new Error(data.error||"Unable to load article");
    displayArticle(data);
  }catch(error){
    console.error(error);
    showToast(error.message||"This article could not be loaded.");
  }
});

function displayArticle(data){
  home.classList.add("hidden");
  reader.classList.remove("hidden");
  controls.classList.remove("hidden");
  window.scrollTo({top:0,behavior:"instant"});
  title.textContent=data.title||"Untitled article";
  description.textContent=data.description||"";
  if(data.image){image.src=data.image;image.classList.remove("hidden")}
  else image.classList.add("hidden");
  content.innerHTML=data.content||"<p>No readable content found.</p>";
  source.textContent=data.siteName||"Web article";
  const words=content.innerText.trim().split(/\s+/).length;
  readingTime.textContent=`${Math.max(1,Math.ceil(words/220))} min read`;
}

backBtn.addEventListener("click",()=>{
  reader.classList.add("hidden");
  controls.classList.add("hidden");
  home.classList.remove("hidden");
  window.scrollTo({top:0,behavior:"smooth"});
});

window.addEventListener("scroll",()=>{
  if(reader.classList.contains("hidden"))return;
  const max=document.documentElement.scrollHeight-window.innerHeight;
  const percentage=max>0?(window.scrollY/max)*100:0;
  progressBar.style.width=`${Math.min(100,percentage)}%`;
});

themeBtn.addEventListener("click",()=>{
  document.body.classList.toggle("dark");
  localStorage.setItem("darkMode",document.body.classList.contains("dark"));
});
if(localStorage.getItem("darkMode")==="true")document.body.classList.add("dark");

settingsBtn.addEventListener("click",()=>settings.classList.toggle("open"));
closeSettings.addEventListener("click",()=>settings.classList.remove("open"));

fontSlider.addEventListener("input",()=>document.documentElement.style.setProperty("--article-size",`${fontSlider.value}px`));
spacingSlider.addEventListener("input",()=>document.documentElement.style.setProperty("--article-spacing",spacingSlider.value));

increaseFont.addEventListener("click",()=>{
  let value=Math.min(26,parseInt(fontSlider.value)+1);
  fontSlider.value=value;fontSlider.dispatchEvent(new Event("input"));
});
decreaseFont.addEventListener("click",()=>{
  let value=Math.max(16,parseInt(fontSlider.value)-1);
  fontSlider.value=value;fontSlider.dispatchEvent(new Event("input"));
});

shareBtn.addEventListener("click",async()=>{
  try{await navigator.clipboard.writeText(window.location.href);showToast("Link copied")}
  catch{showToast("Unable to copy link")}
});

let toastTimer;
function showToast(message){
  toast.textContent=message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer=setTimeout(()=>toast.classList.remove("show"),2200);
}
